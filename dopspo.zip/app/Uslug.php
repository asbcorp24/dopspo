<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Uslug extends Model
{
    protected $table = 'uslug';
}
